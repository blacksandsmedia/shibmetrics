"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/update-burn-data.ts
var update_burn_data_exports = {};
__export(update_burn_data_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(update_burn_data_exports);

// node_modules/@netlify/functions/dist/main.js
var import_stream = require("stream");
var import_util = require("util");
var schedule = (cron, handler2) => handler2;
var pipeline = (0, import_util.promisify)(import_stream.pipeline);

// lib/burn-cache.ts
var import_fs = __toESM(require("fs"));
var import_path = __toESM(require("path"));
var CACHE_FILE_PATH = import_path.default.join(process.cwd(), ".cache", "burn-data.json");
function ensureCacheDir() {
  const cacheDir = import_path.default.dirname(CACHE_FILE_PATH);
  if (!import_fs.default.existsSync(cacheDir)) {
    import_fs.default.mkdirSync(cacheDir, { recursive: true });
  }
}
function saveBurnCache(data) {
  try {
    ensureCacheDir();
    import_fs.default.writeFileSync(CACHE_FILE_PATH, JSON.stringify(data, null, 2));
    console.log(`\u2705 Saved burn cache: ${data.transactions.length} transactions`);
  } catch (error) {
    console.error("\u274C Failed to save burn cache:", error);
  }
}

// netlify/functions/update-burn-data.ts
var SHIB_CONTRACT_ADDRESS = "0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce";
var scheduledHandler = async (event, context) => {
  console.log("\u{1F525} Starting scheduled burn data update...");
  const apiKey = process.env.NEXT_PUBLIC_ETHERSCAN_API_KEY;
  if (!apiKey || apiKey === "YourEtherscanApiKeyHere") {
    console.error("\u274C No valid Etherscan API key configured");
    return { statusCode: 500, body: "No API key" };
  }
  const burnAddresses = [
    { name: "BA-1 (Vitalik Burn Alt)", address: "0xdead000000000000000042069420694206942069" },
    { name: "BA-2 (Dead Address 1)", address: "0x000000000000000000000000000000000000dead" },
    { name: "BA-3 (Null Address)", address: "0x0000000000000000000000000000000000000000" },
    { name: "CA (Community Address)", address: "0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce" }
  ];
  const allTransactions = [];
  let successCount = 0;
  for (const burnAddr of burnAddresses) {
    let success = false;
    for (let attempt = 1; attempt <= 3 && !success; attempt++) {
      try {
        const requestUrl = `https://api.etherscan.io/api?module=account&action=tokentx&contractaddress=${SHIB_CONTRACT_ADDRESS}&address=${burnAddr.address}&page=1&offset=8&sort=desc&apikey=${apiKey}`;
        console.log(`\u{1F525} Fetching from ${burnAddr.name} (attempt ${attempt})...`);
        const response = await fetch(requestUrl, {
          method: "GET",
          headers: { "Accept": "application/json" }
        });
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();
        if (data.status === "1" && data.result && Array.isArray(data.result)) {
          const transactions = data.result.filter((tx) => tx.to?.toLowerCase() === burnAddr.address.toLowerCase()).slice(0, 6).map((tx) => ({
            hash: tx.hash,
            from: tx.from,
            to: tx.to,
            value: tx.value,
            timeStamp: tx.timeStamp,
            blockNumber: tx.blockNumber,
            tokenName: tx.tokenName || "SHIBA INU",
            tokenSymbol: tx.tokenSymbol || "SHIB",
            tokenDecimal: tx.tokenDecimal || "18"
          }));
          allTransactions.push(...transactions);
          successCount++;
          success = true;
          console.log(`\u2705 ${burnAddr.name}: Found ${transactions.length} transactions`);
        } else {
          throw new Error(`Etherscan API returned status: ${data.status}, message: ${data.message || "Unknown"}`);
        }
        if (attempt === 1) await new Promise((resolve) => setTimeout(resolve, 300));
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        console.warn(`\u26A0\uFE0F ${burnAddr.name} attempt ${attempt} failed: ${errorMessage}`);
        if (attempt < 3) {
          await new Promise((resolve) => setTimeout(resolve, 1e3 * attempt));
        }
      }
    }
    if (!success) {
      console.error(`\u274C ${burnAddr.name}: All attempts failed`);
    }
  }
  allTransactions.sort((a, b) => parseInt(b.timeStamp) - parseInt(a.timeStamp));
  const topTransactions = allTransactions.slice(0, 20);
  const cacheData = {
    transactions: topTransactions,
    lastUpdated: Date.now(),
    source: "scheduled-etherscan",
    totalAddressesSuccess: successCount,
    totalAddressesAttempted: burnAddresses.length
  };
  saveBurnCache(cacheData);
  console.log(`\u2705 Scheduled update complete: ${topTransactions.length} transactions from ${successCount}/${burnAddresses.length} addresses`);
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: "Burn data updated successfully",
      transactions: topTransactions.length,
      addressesSuccess: successCount,
      addressesAttempted: burnAddresses.length,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    })
  };
};
var handler = schedule("*/3 * * * *", scheduledHandler);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
