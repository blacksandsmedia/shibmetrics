"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/scheduled-refresh.ts
var scheduled_refresh_exports = {};
__export(scheduled_refresh_exports, {
  config: () => config,
  default: () => scheduled_refresh_default
});
module.exports = __toCommonJS(scheduled_refresh_exports);
var scheduled_refresh_default = async (request, context) => {
  console.log("\u{1F550} Scheduled refresh starting...");
  try {
    const baseUrl = process.env.NETLIFY_DEV ? "http://localhost:8888" : "https://shibmetrics.com";
    const refreshPromises = [
      fetch(`${baseUrl}/api/price`, {
        method: "GET",
        headers: { "User-Agent": "Netlify-Scheduled-Refresh" }
      }),
      fetch(`${baseUrl}/api/total-burned`, {
        method: "GET",
        headers: { "User-Agent": "Netlify-Scheduled-Refresh" }
      }),
      fetch(`${baseUrl}/api/burns`, {
        method: "GET",
        headers: { "User-Agent": "Netlify-Scheduled-Refresh" }
      })
    ];
    const results = await Promise.allSettled(refreshPromises);
    let successCount = 0;
    let failCount = 0;
    results.forEach((result, index) => {
      const endpoints = ["price", "total-burned", "burns"];
      if (result.status === "fulfilled") {
        console.log(`\u2705 ${endpoints[index]}: HTTP ${result.value.status}`);
        successCount++;
      } else {
        console.error(`\u274C ${endpoints[index]}: ${result.reason}`);
        failCount++;
      }
    });
    console.log(`\u{1F3C1} Scheduled refresh complete: ${successCount} success, ${failCount} failed`);
    return new Response(JSON.stringify({
      message: "Scheduled refresh completed",
      success: successCount,
      failed: failCount,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (error) {
    console.error("\u274C Scheduled refresh error:", error);
    return new Response(JSON.stringify({
      error: "Scheduled refresh failed",
      message: error instanceof Error ? error.message : "Unknown error",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
var config = {
  schedule: "*/2 * * * *"
  // Every 2 minutes
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
