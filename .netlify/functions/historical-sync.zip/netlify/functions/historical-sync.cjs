"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/historical-sync.ts
var historical_sync_exports = {};
__export(historical_sync_exports, {
  config: () => config,
  default: () => historical_sync_default
});
module.exports = __toCommonJS(historical_sync_exports);
var import_fs = __toESM(require("fs"));
var SHIB_CONTRACT_ADDRESS = "0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce";
var HISTORICAL_CACHE_FILE = "/tmp/historical-burns.json";
var BURN_ADDRESSES = [
  { name: "BA-1 (Vitalik Burn Alt)", address: "0xdead000000000000000042069420694206942069" },
  { name: "BA-2 (Dead Address 1)", address: "0x000000000000000000000000000000000000dead" },
  { name: "BA-3 (Null Address)", address: "0x0000000000000000000000000000000000000000" },
  { name: "CA (Community Address)", address: "0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce" }
];
function loadHistoricalCache() {
  try {
    if (!import_fs.default.existsSync(HISTORICAL_CACHE_FILE)) {
      console.log("\u{1F4DA} No historical cache file found, starting fresh");
      return null;
    }
    const data = JSON.parse(import_fs.default.readFileSync(HISTORICAL_CACHE_FILE, "utf8"));
    const burnsMap = /* @__PURE__ */ new Map();
    if (data.burns && Array.isArray(data.burns)) {
      for (const [key, value] of data.burns) {
        burnsMap.set(key, value);
      }
    }
    return {
      ...data,
      burns: burnsMap
    };
  } catch (error) {
    console.error("\u274C Failed to load historical cache:", error);
    return null;
  }
}
function saveHistoricalCache(cache) {
  try {
    const serializable = {
      ...cache,
      burns: Array.from(cache.burns.entries())
    };
    import_fs.default.writeFileSync(HISTORICAL_CACHE_FILE, JSON.stringify(serializable, null, 2));
    console.log(`\u2705 Saved historical cache: ${cache.totalBurns} total burns`);
  } catch (error) {
    console.error("\u274C Failed to save historical cache:", error);
  }
}
function addBurnsToHistory(newBurns) {
  const cache = loadHistoricalCache() || {
    burns: /* @__PURE__ */ new Map(),
    lastFullSync: 0,
    oldestBlock: "0",
    totalBurns: 0,
    addresses: {}
  };
  let addedCount = 0;
  const now = Date.now();
  for (const burn of newBurns) {
    if (!cache.burns.has(burn.hash)) {
      cache.burns.set(burn.hash, { ...burn, firstSeen: now });
      addedCount++;
      const addressKey = burn.to;
      if (!cache.addresses[addressKey]) {
        cache.addresses[addressKey] = { lastBlock: "0", totalBurns: 0 };
      }
      cache.addresses[addressKey].totalBurns++;
      if (cache.oldestBlock === "0" || parseInt(burn.blockNumber) < parseInt(cache.oldestBlock)) {
        cache.oldestBlock = burn.blockNumber;
      }
    }
  }
  cache.totalBurns = cache.burns.size;
  cache.lastFullSync = now;
  console.log(`\u{1F4DA} Added ${addedCount} new burns to historical cache (total: ${cache.totalBurns})`);
  saveHistoricalCache(cache);
  return cache;
}
async function fetchHistoricalBurns() {
  const apiKey = process.env.NEXT_PUBLIC_ETHERSCAN_API_KEY;
  if (!apiKey || apiKey === "YourEtherscanApiKeyHere") {
    console.log("\u26A0\uFE0F No API key for historical sync");
    return;
  }
  try {
    console.log("\u{1F4DA} Starting deep historical burn sync...");
    const newBurns = [];
    for (const burnAddr of BURN_ADDRESSES) {
      try {
        const requestUrl = `https://api.etherscan.io/api?module=account&action=tokentx&contractaddress=${SHIB_CONTRACT_ADDRESS}&address=${burnAddr.address}&page=1&offset=100&sort=desc&apikey=${apiKey}`;
        console.log(`\u{1F4DA} Historical sync: Fetching 100 transactions from ${burnAddr.name}...`);
        const response = await fetch(requestUrl, {
          method: "GET",
          headers: { "Accept": "application/json" }
        });
        if (!response.ok) {
          console.log(`\u26A0\uFE0F HTTP ${response.status} for ${burnAddr.name} - continuing anyway`);
          continue;
        }
        const data = await response.json();
        console.log(`\u{1F4CA} ${burnAddr.name}: status=${data.status}, results=${data.result?.length || 0}`);
        if (data.result && Array.isArray(data.result) && data.result.length > 0) {
          const transactions = data.result.filter((tx) => {
            try {
              const value = BigInt(tx.value || "0");
              return value > BigInt(0);
            } catch {
              return false;
            }
          }).map((tx) => ({
            hash: tx.hash,
            from: tx.from,
            to: tx.to,
            value: tx.value,
            timeStamp: tx.timeStamp,
            blockNumber: tx.blockNumber,
            tokenName: tx.tokenName,
            tokenSymbol: tx.tokenSymbol,
            tokenDecimal: tx.tokenDecimal
          }));
          newBurns.push(...transactions);
          console.log(`\u2705 ${burnAddr.name}: Found ${transactions.length} valid historical burns`);
        }
        await new Promise((resolve) => setTimeout(resolve, 2e3));
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        console.log(`\u274C Historical sync error for ${burnAddr.name}: ${errorMessage}`);
      }
    }
    if (newBurns.length > 0) {
      addBurnsToHistory(newBurns);
      console.log(`\u2705 Historical sync complete: processed ${newBurns.length} transactions`);
    } else {
      console.log("\u2139\uFE0F Historical sync complete: no new transactions found");
    }
  } catch (error) {
    console.error("\u274C Historical sync failed:", error);
  }
}
var historical_sync_default = async (request, context) => {
  console.log("\u{1F4DA} Scheduled historical sync starting...");
  try {
    await fetchHistoricalBurns();
    return new Response(JSON.stringify({
      message: "Historical sync completed",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (error) {
    console.error("\u274C Scheduled historical sync error:", error);
    return new Response(JSON.stringify({
      error: "Historical sync failed",
      message: error instanceof Error ? error.message : "Unknown error",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
var config = {
  schedule: "*/10 * * * *"
  // Every 10 minutes
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
