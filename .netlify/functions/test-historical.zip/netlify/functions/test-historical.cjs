"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/test-historical.ts
var test_historical_exports = {};
__export(test_historical_exports, {
  default: () => test_historical_default
});
module.exports = __toCommonJS(test_historical_exports);
var test_historical_default = async (request, context) => {
  console.log("\u{1F9EA} Test historical function starting...");
  try {
    const apiKey = process.env.NEXT_PUBLIC_ETHERSCAN_API_KEY || process.env.ETHERSCAN_API_KEY;
    console.log("\u{1F511} API Key available:", !!apiKey);
    console.log("\u{1F511} API Key prefix:", apiKey ? apiKey.substring(0, 10) + "..." : "None");
    const testUrl = `https://api.etherscan.io/api?module=account&action=tokentx&contractaddress=0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce&address=0xdead000000000000000042069420694206942069&page=1&offset=5&sort=desc&apikey=${apiKey}`;
    console.log("\u{1F9EA} Testing Etherscan API call...");
    const response = await fetch(testUrl);
    const data = await response.json();
    console.log("\u{1F4CA} API Response:", {
      status: response.status,
      etherscanStatus: data.status,
      resultCount: data.result?.length || 0
    });
    return new Response(JSON.stringify({
      message: "Test completed successfully",
      apiKeyAvailable: !!apiKey,
      apiKeyPrefix: apiKey ? apiKey.substring(0, 10) + "..." : "None",
      etherscanStatus: data.status,
      resultCount: data.result?.length || 0,
      sampleTransaction: data.result?.[0] || null,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  } catch (error) {
    console.error("\u274C Test function error:", error);
    return new Response(JSON.stringify({
      error: "Test failed",
      message: error instanceof Error ? error.message : "Unknown error",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
